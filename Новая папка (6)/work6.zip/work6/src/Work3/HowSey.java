package Work3;

public class HowSey {
    @SuppressWarnings("unused")
    private String formality;

    public void setFormality(String formality) {
        this.formality = formality;
    }
    
}
