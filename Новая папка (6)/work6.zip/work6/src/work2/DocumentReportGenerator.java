package work2;
//Здесь создание отчета документа генерируется от класса создания отчета
public class DocumentReportGenerator extends ReportGenerator {
// дополнительная логика
}
