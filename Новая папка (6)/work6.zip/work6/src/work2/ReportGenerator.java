package work2;
// сделал логику в генераторе отчета
public class ReportGenerator {


    String generateXml() {
        String report = "";
        // todo Logic
        return report;
    }

    String generateJson() {
        String report = "";
        // todo Logic
        return report;
    }
}
