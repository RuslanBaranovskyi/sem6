package work2;
//Здесь создание отчета аккаунта генерируется от класса создания отчета
public class AccountReportGenerator extends ReportGenerator {
// дополнительная логика
}
